import React from 'react'

const Chart = () => {
  return (
    <div>
      <h1>Chart</h1>
    </div>
  )
}

export default Chart
