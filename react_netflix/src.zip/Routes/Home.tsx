import React from 'react'

const Home = () => {
  return (
    <div style={{backgroundColor: 'whitesmoke', height: '200vh'}}>
      
    </div>
  )
}

export default Home
