import React from 'react'

const Tv = () => {
  return (
    <h1>
      TV Show
    </h1>
  )
}

export default Tv
